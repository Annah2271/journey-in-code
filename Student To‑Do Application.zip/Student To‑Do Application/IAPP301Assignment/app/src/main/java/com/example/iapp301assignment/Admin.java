package com.example.iapp301assignment;


import androidx.appcompat.app.AppCompatActivity;

import android.app.ListActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class Admin extends ListActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);


        String[] txtAdminTasks = {"Student Records", "Instructor Records", "Module Records"};
        setListAdapter(new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, txtAdminTasks));
    }
    protected void onListItemClick(ListView l, View v, int position, long id){
        switch(position){
            case 0:
                startActivity(new Intent(Admin.this, StudentRecords.class));

                break;
            case 1:
                startActivity(new Intent(Admin.this, InstructorRecords.class));

                break;
            case 2:
                startActivity(new Intent(Admin.this, ModuleRecords.class));

                break;
        }
    }
}
