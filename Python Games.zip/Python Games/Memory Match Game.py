import tkinter as tk
from tkinter import messagebox
import random
import time
from typing import Dict, List


class MemoryMatchGame:
    def __init__(self, master: tk.Tk):
        self.master = master
        self.master.title("Memory Match Game")

        # Game configuration
        self.rows = 4
        self.cols = 4
        self.card_size = 80
        self.delay = 1000  # milliseconds before flipping back
        self.fruits = ["🍎", "🍌", "🍇", "🍊", "🍓", "🍒", "🍑", "🍍"] * 2

        # Game state
        self.cards: List[List[Dict]] = []
        self.flipped: List[Dict] = []
        self.matched_pairs = 0
        self.moves = 0
        self.game_started = False
        self.start_time = 0.0

        # Initialize UI elements
        self.game_frame = tk.Frame(self.master)
        self.info_frame = tk.Frame(self.master)
        self.move_label = tk.Label(self.info_frame, text="Moves: 0", font=('Arial', 12))
        self.time_label = tk.Label(self.info_frame, text="Time: 0s", font=('Arial', 12))
        self.button_frame = tk.Frame(self.master)
        self.reset_button = tk.Button(self.button_frame, text="New Game", command=self.reset_game)

        self.create_widgets()
        self.setup_game()

    def create_widgets(self) -> None:
        # Game frame
        self.game_frame.pack(pady=20)

        # Info frame
        self.info_frame.pack(pady=10)
        self.move_label.pack(side=tk.LEFT, padx=10)
        self.time_label.pack(side=tk.LEFT, padx=10)

        # Button frame
        self.button_frame.pack(pady=10)
        self.reset_button.pack()

    def setup_game(self) -> None:
        # Clear any existing cards
        for widget in self.game_frame.winfo_children():
            widget.destroy()

        # Reset game state
        self.cards = []
        self.flipped = []
        self.matched_pairs = 0
        self.moves = 0
        self.game_started = False
        self.move_label.config(text="Moves: 0")
        self.time_label.config(text="Time: 0s")

        # Shuffle the fruits
        random.shuffle(self.fruits)

        # Create cards
        for row_idx in range(self.rows):
            row = []
            for col_idx in range(self.cols):
                index = row_idx * self.cols + col_idx
                card = tk.Button(
                    self.game_frame,
                    text=" ",  # Initially face down
                    font=('Arial', 24),
                    width=3,
                    height=1,
                    command=lambda r=row_idx, c=col_idx: self.card_click(r, c),
                    relief=tk.RAISED,
                    bg="light blue"
                )
                card.grid(row=row_idx, column=col_idx, padx=5, pady=5)
                row.append({
                    "button": card,
                    "fruit": self.fruits[index],
                    "matched": False,
                    "row": row_idx,
                    "col": col_idx
                })
            self.cards.append(row)

    def card_click(self, row: int, col: int) -> None:
        card = self.cards[row][col]

        # Ignore if card is already flipped or matched
        if card in self.flipped or card["matched"]:
            return

        # Start timer on first move
        if not self.game_started:
            self.game_started = True
            self.start_time = time.time()
            self.update_timer()

        # Flip the card
        self.flip_card(card, True)
        self.flipped.append(card)

        # Check for match
        if len(self.flipped) == 2:
            self.moves += 1
            self.move_label.config(text=f"Moves: {self.moves}")

            if self.flipped[0]["fruit"] == self.flipped[1]["fruit"]:
                # Match found
                for c in self.flipped:
                    c["matched"] = True
                    c["button"].config(bg="light green", state=tk.DISABLED)
                self.flipped = []
                self.matched_pairs += 1

                # Check for game completion
                if self.matched_pairs == len(self.fruits) // 2:
                    elapsed = int(time.time() - self.start_time)
                    messagebox.showinfo(
                        "Congratulations!",
                        f"You won in {self.moves} moves and {elapsed} seconds!"
                    )
                    # Restart the game after a short delay
                    self.master.after(2000, self.reset_game)
            else:
                # No match - flip back after delay
                self.master.after(self.delay, self.flip_back)

    @staticmethod
    def flip_card(card: Dict, face_up: bool) -> None:
        if face_up:
            card["button"].config(text=card["fruit"], bg="white")
        else:
            card["button"].config(text=" ", bg="light blue")

    def flip_back(self) -> None:
        for card in self.flipped:
            self.flip_card(card, False)
        self.flipped = []

    def update_timer(self) -> None:
        if self.game_started:
            elapsed = int(time.time() - self.start_time)
            self.time_label.config(text=f"Time: {elapsed}s")
            self.master.after(1000, self.update_timer)

    def reset_game(self) -> None:
        self.setup_game()


if __name__ == "__main__":
    root = tk.Tk()
    game = MemoryMatchGame(root)
    root.mainloop()