import periodictable 
from tabulate import tabulate
from colorama import Fore, Style, init

init(autoreset=True)
while True:
    element_symbol = input("Enter an element symbol ('q' to quit): ")

    if element_symbol.lower() == 'q':
        print(Fore.YELLOW + "Goodbye! 👋")
        break

    element = getattr(periodictable.elements, element_symbol)

    if element and hasattr(element, 'name'):
        table = [
            ["Name", element.name],
            ["Symbol", element.symbol],
            ["Atomic Number", element.number],
            ["Density (g/cm³)", element.density]
        ]
        print(Fore.GREEN + "\nElement Information:")
        print(Fore.MAGENTA + tabulate(table, headers=["Property", "Value"], tablefmt="fancy_grid"))
        print()
    else:
        print(Fore.RED + "Invalid element symbol. Please try again.\n")





