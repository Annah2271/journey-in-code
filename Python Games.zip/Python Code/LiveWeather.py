import requests
from rich.console import Console
from rich.table import Table

console = Console()
cities = ["Gqeberha", "Welkom", "Cape Town", "Durban"]

table = Table(title="🌤️ Weather Dashboard", style="cyan")
table.add_column("City", justify="center")
table.add_column("Temperature (°C)", justify="center")

for city in cities:
    try:
        response = requests.get(f"https://wttr.in/{city}?format=%t")
        temp = response.text.strip()
    except Exception as e:
        temp = f"Error: {e}"
    table.add_row(city, temp)

console.print(table)
