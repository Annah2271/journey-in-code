from datetime import datetime
import pytz
from rich.console import Console
from rich.table import Table

console = Console()

# Valid timezone names from pytz
cities = {
    "Kolkata": "Asia/Kolkata",
    "London": "Europe/London",
    "Cape Town": "Africa/Johannesburg",
    "Accra": "Africa/Accra",             
    "Maputo": "Africa/Maputo",           
    "Antananarivo": "Indian/Antananarivo" 
}

table = Table(title="🌍 World Clock", style="cyan", show_header=True)
table.add_column("City", style="magenta", justify="center")
table.add_column("Current Time", style="green", justify="center")

for city_name, tz_name in cities.items():
    tz = pytz.timezone(tz_name)
    current_time = datetime.now(tz).strftime('%H:%M:%S')
    table.add_row(city_name, current_time)

console.print(table)
