import time, random

sentences = [
    "Python is fun to code!", 
    "Typing speed test is fun!",
    "I love coding games!"
]

while True:
    text = random.choice(sentences)
    print("Type the following sentence as fast as you can:\n")
    print(f"📝 {text}\n")

    start = time.time()
    typed = input("Your input: ")
    end = time.time()

    time_taken = end - start
    accuracy = sum(a==b for a,b in zip(text,typed))/len(text)*100
    wpm = len(typed.split())/ (time_taken/60)

    print(f"\n⏰ Time: {time_taken:.2f} sec")
    print(f"✅  Accuracy: {accuracy:.2f}%")
    print(f"✍️  Words per minute: {wpm:.2f} WPM")

    again = input("\n🔁 Try again? (y/n): ").strip().lower()
    if again != 'y':
        print("\n👋Thanks for playing! Keep practicing!")
 
