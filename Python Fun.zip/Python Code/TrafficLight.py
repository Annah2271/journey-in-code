import tkinter as tk

root = tk.Tk()
root.title("Traffic Light Simulation")

canvas = tk.Canvas(root, width=200, height=400, bg="black")
canvas.pack()

# Create three lights
red_light = canvas.create_oval(50, 50, 150, 150, fill="grey")
yellow_light = canvas.create_oval(50, 160, 150, 260, fill="grey")
green_light = canvas.create_oval(50, 270, 150, 370, fill="grey")

def set_light(active):
    # Reset all to grey
    canvas.itemconfig(red_light, fill="grey")
    canvas.itemconfig(yellow_light, fill="grey")
    canvas.itemconfig(green_light, fill="grey")

    # Activate one
    if active == "red":
        canvas.itemconfig(red_light, fill="red")
        root.after(2000, lambda: set_light("yellow"))
    elif active == "yellow":
        canvas.itemconfig(yellow_light, fill="yellow")
        root.after(1000, lambda: set_light("green"))
    elif active == "green":
        canvas.itemconfig(green_light, fill="green")
        root.after(2000, lambda: set_light("red"))

# Start the loop
set_light("red")

root.mainloop()
