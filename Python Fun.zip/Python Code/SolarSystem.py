import numpy as np
import matplotlib.pyplot as plt

t = np.linspace(0,2*np.pi,200)
plt.plot(np.cos(t), np.sin(t), 'y')
plt.scatter(0,0,s=300,c='orange',label='Sun')
plt.scatter(np.cos(t)*0.5, np.sin(t)*0.5, s=40, c='blue', label="Earth")
plt.scatter(np.cos(t)*0.3, np.sin(t)*0.3,s=20,c='grey',label='Mecury')
plt.scatter(np.cos(t)*0.7, np.sin(t)*0.7,s=25,c='red',label='Mars')
plt.gca().set_facecolor("black")
plt.axis("eqaul")
ply.legend()
plt.title("Simple Solar Sytem")
plt.show()
