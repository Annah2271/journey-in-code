import random
import tkinter as tk
from PIL import Image, ImageTk, ImageEnhance

user_count = 0
computer_count = 0
choices = ("rock", "paper", "scissors")

emoji_map = {
    "rock": "✊",
    "paper": "🖐️",
    "scissors": "✌️"
}

def play(user_choice):
    global user_count, computer_count

    computer_choice = random.choice(choices)

    if user_choice == computer_choice:
        output = "It's a tie!😁"
    elif (
        (user_choice == "rock" and computer_choice == "scissors") or
        (user_choice == "scissors" and computer_choice == "paper") or
        (user_choice == "paper" and computer_choice == "rock")
    ):
        output = "You Win!"
        user_count += 1
    else:
        output = "Computer Win!"
        computer_count += 1

    score_text.set(f"Player: {user_count} | Computer: {computer_count}")
    choice_text.set(f"Player: {user_choice} | Computer: {computer_choice}")
    output_text.set(output)

    show_choices(user_choice, computer_choice)

def show_choices(user_choice, computer_choice):
    canvas.delete("all")
    canvas.create_image(0, 0, image=canvas_bg_ref[0], anchor="nw")

    # Width of canvas
    canvas_width = 400
    canvas_height = 150

    # Midpoints of each side
    player_x = canvas_width // 4      # 100
    computer_x = 3 * canvas_width // 4  # 300
    center_y = canvas_height // 2     # 75

    # Create text off-canvas to measure width
    player_emoji = emoji_map[user_choice]
    computer_emoji = emoji_map[computer_choice]

    temp_player = canvas.create_text(0, 0, text=player_emoji, font=("Arial", 40))
    temp_computer = canvas.create_text(0, 0, text=computer_emoji, font=("Arial", 40))
    player_bbox = canvas.bbox(temp_player)
    computer_bbox = canvas.bbox(temp_computer)
    player_width = player_bbox[2] - player_bbox[0] if player_bbox else 0
    computer_width = computer_bbox[2] - computer_bbox[0] if computer_bbox else 0
    canvas.delete(temp_player)
    canvas.delete(temp_computer)

    # Adjust x so emoji is visually centered
    player_x_adj = player_x - player_width // 2
    computer_x_adj = computer_x - computer_width // 2

    # Make emoji colors darker for better contrast
    player_pop = canvas.create_text(player_x_adj, center_y, text=player_emoji,
                                    font=("Arial", 40), fill="yellow", tags="player", anchor="nw")

    comp_pop = canvas.create_text(computer_x_adj, center_y, text=computer_emoji,
                                  font=("Arial", 40), fill="yellow", tags="computer", anchor="nw")

    def animate_growth(item, size=40):
        if size < 60:
            size += 2
            canvas.itemconfig(item, font=("Arial", size))
            root.after(50, lambda: animate_growth(item, size))

    animate_growth(player_pop)
    animate_growth(comp_pop)


def reset_scores():
    global user_count, computer_count
    user_count = 0
    computer_count = 0
    score_text.set("Player: 0 | Computer: 0")
    output_text.set("")
    choice_text.set("")
    canvas.delete("player")
    canvas.delete("computer")

root = tk.Tk()
root.title("Rock Paper Scissors Game")

# Load and dim the background image
bg_raw = Image.open("Images/wallpape.webp").resize((390, 187))
dimmer = ImageEnhance.Brightness(bg_raw)
bg_dimmed = dimmer.enhance(0.35)  # More dimmed for better emoji contrast
bg_image = ImageTk.PhotoImage(bg_dimmed)
canvas_bg_ref = [bg_image]

score_text = tk.StringVar()
output_text = tk.StringVar()
choice_text = tk.StringVar()

score_text.set("Player: 0 | Computer: 0")

# Scoreboard up top
score_label = tk.Label(root, textvariable=score_text, font=("Arial", 14, "bold"), bg="#222", fg="#fff", pady=5)
score_label.pack(pady=5, fill="x")

# Canvas split between Player (left) and Computer (right)
canvas = tk.Canvas(root, width=390, height=187, highlightthickness=0)
canvas.pack()
canvas.create_image(0, 0, image=canvas_bg_ref[0], anchor="nw")

# Result text
output_label = tk.Label(root, textvariable=output_text, font=("Arial", 14, "bold"), fg="#333")
output_label.pack(pady=5)
choice_label = tk.Label(root, textvariable=choice_text, font=("Arial", 12), fg="#555")
choice_label.pack(pady=3)

# Buttons
frame = tk.Frame(root, bg="#333")
frame.pack(pady=10)

btn_style = {"width": 10, "font": ("Arial", 12, "bold"), "bg": "#4a90e2", "fg": "#fff", "activebackground": "#357ab7", "activeforeground": "#fff", "bd": 0, "relief": "flat"}
tk.Button(frame, text="Rock", command=lambda: play("rock"), **btn_style).grid(row=0, column=0, padx=5)
tk.Button(frame, text="Paper", command=lambda: play("paper"), **btn_style).grid(row=0, column=1, padx=5)
tk.Button(frame, text="Scissors", command=lambda: play("scissors"), **btn_style).grid(row=0, column=2, padx=5)

reset_btn = tk.Button(root, text="Reset Scores", command=reset_scores, font=("Arial", 11, "bold"), bg="#e94e77", fg="#fff", activebackground="#b03a5b", activeforeground="#fff", bd=0, relief="flat")
reset_btn.pack(pady=5)

root.mainloop()
